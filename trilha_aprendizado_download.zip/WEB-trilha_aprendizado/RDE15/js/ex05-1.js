var nome, n
nome=prompt("Qual o seu nome?")
n=parseFloat(prompt(nome+" digite um valor: "))

if (n%2==0) {
    alert(nome+" o número digitado é par")
}
else{
    alert(nome+" o número digitado é ímpar")
}




