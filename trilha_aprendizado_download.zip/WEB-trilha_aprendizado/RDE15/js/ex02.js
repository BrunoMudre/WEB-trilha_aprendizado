var frase, n1, n2, soma

frase="Testando Strings em JS"
alert(frase)
n1=5
n2=10
soma=n1+n2
alert(n1+"+"+n2+"="+soma)